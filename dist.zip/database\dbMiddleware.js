"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupDbContext = setupDbContext;
const postgresClient_1 = __importDefault(require("./postgresClient"));
/**
 * Middleware to add database connection to the InvocationContext
 * @param context The function invocation context
 */
function setupDbContext(context) {
    // Add db property to context
    context.db = {
        query: async (text, params) => {
            try {
                const result = await postgresClient_1.default.query(text, params);
                return {
                    rows: result.rows,
                    rowCount: result.rowCount
                };
            }
            catch (error) {
                context.log('Database query error:', error);
                throw error;
            }
        }
    };
}
//# sourceMappingURL=dbMiddleware.js.map