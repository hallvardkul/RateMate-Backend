"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.test = test;
const corsMiddleware_1 = require("../utils/corsMiddleware");
async function test(request, context) {
    // Handle CORS preflight requests
    if (request.method === 'OPTIONS') {
        return (0, corsMiddleware_1.handleCorsPreflight)();
    }
    try {
        const response = {
            status: 200,
            jsonBody: {
                message: "Test endpoint working",
                timestamp: new Date().toISOString()
            }
        };
        return (0, corsMiddleware_1.addCorsHeaders)(response);
    }
    catch (error) {
        context.error('Error in test function:', error);
        return (0, corsMiddleware_1.addCorsHeaders)({
            status: 500,
            jsonBody: { error: 'Internal server error' }
        });
    }
}
//# sourceMappingURL=test.js.map