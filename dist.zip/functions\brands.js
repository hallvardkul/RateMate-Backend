"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.brands = void 0;
const functions_1 = require("@azure/functions");
const brandsService_1 = require("../services/brandsService");
const rateLimitMiddleware_1 = require("../utils/rateLimitMiddleware");
const corsMiddleware_1 = require("../utils/corsMiddleware");
// Register the brands function
exports.brands = functions_1.app.http('brands', {
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    authLevel: 'anonymous',
    route: "brands/{id?}",
    handler: async (req, ctx) => {
        // Rate-limit guard
        const limited = (0, rateLimitMiddleware_1.rateLimit)(req, ctx);
        if (limited)
            return limited;
        // CORS preflight
        if (req.method === 'OPTIONS')
            return (0, corsMiddleware_1.handleCorsPreflight)();
        // Execute original handler and add CORS headers
        const resp = await (0, brandsService_1.BrandsFunction)(req, ctx);
        return (0, corsMiddleware_1.addCorsHeaders)(resp);
    }
});
//# sourceMappingURL=brands.js.map