"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
require("./functions/auth");
require("./functions/brands");
require("./functions/user");
require("./functions/reviews");
require("./functions/comments");
require("./functions/categories");
require("./functions/products");
require("./functions/media");
require("./functions/health");
// Removed legacy functions.ts import
// Re-export all functions to ensure they are registered
__exportStar(require("./functions/auth"), exports);
__exportStar(require("./functions/brands"), exports);
__exportStar(require("./functions/user"), exports);
__exportStar(require("./functions/reviews"), exports);
__exportStar(require("./functions/comments"), exports);
__exportStar(require("./functions/categories"), exports);
__exportStar(require("./functions/products"), exports);
__exportStar(require("./functions/media"), exports);
__exportStar(require("./functions/health"), exports);
// Removed legacy functions.ts export 
//# sourceMappingURL=index.js.map