"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCollection = getCollection;
exports.closeConnection = closeConnection;
const mongodb_1 = require("mongodb");
let client = null;
async function getCollection() {
    if (!client) {
        if (!process.env.COSMOS_CONNECTION_STRING) {
            throw new Error('COSMOS_CONNECTION_STRING environment variable is not set');
        }
        client = new mongodb_1.MongoClient(process.env.COSMOS_CONNECTION_STRING);
        await client.connect();
        console.log('Connected to Cosmos DB');
    }
    const db = client.db(process.env.COSMOS_DB_NAME);
    return db.collection(process.env.COSMOS_COLLECTION_NAME || 'media');
}
async function closeConnection() {
    if (client) {
        await client.close();
        client = null;
        console.log('Closed Cosmos DB connection');
    }
}
//# sourceMappingURL=cosmosClient.js.map