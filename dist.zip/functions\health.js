"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.health = void 0;
const functions_1 = require("@azure/functions");
const corsMiddleware_1 = require("../utils/corsMiddleware");
exports.health = functions_1.app.http("health", {
    methods: ["GET", "OPTIONS"],
    authLevel: "anonymous",
    route: "health",
    handler: async (req, ctx) => {
        if (req.method === "OPTIONS")
            return (0, corsMiddleware_1.handleCorsPreflight)();
        return (0, corsMiddleware_1.addCorsHeaders)({ status: 200, jsonBody: { ok: true } });
    }
});
//# sourceMappingURL=health.js.map